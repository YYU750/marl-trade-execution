# 双机构交易执行仿真（第一阶段）

这是一个单资产、双机构、30 个一分钟步长的教学研究原型。A、B 各有独立的买入订单，同时面对相同的市场中间价、全价差和流动性；本阶段只实现规则型策略，不包含 Q-learning、DQN、PPO 或大型 Agent 框架。

## 市场模型与假设

每个时间步，两个机构先读取同一个不可变市场快照，并分别读取自己的剩余订单量；两边完成 `act(observation)` 后，环境才同时处理交易。观察信息不包含对手方剩余订单、当期行动、随机数状态或未来价格扰动。环境内部保留全部状态。

设当期中间价为 `m_t`，全价差为 `s` 个基点，联合成交量为 `Q_t`，流动性尺度为 `L` 股。每个 Agent 的单步成交量为：

```text
q_i,t = min(floor(action_i,t), remaining_i,t, max_trade_per_step)
Q_t   = q_A,t + q_B,t
temporary_impact_bps = temp_impact_bps_per_liquidity_unit * Q_t / L
permanent_impact_bps = perm_impact_bps_per_liquidity_unit * Q_t / L
fill_price_i,t = m_t * (1 + (s/2 + temporary_impact_bps) / 10000)
m_(t+1) = m_t * exp((shock_bps_t + permanent_impact_bps) / 10000)
```

`s` 是全价差，成交价支付半价差。`shock_bps_t` 是均值为 0、标准差为 `volatility_bps` 的外生正态扰动，由可复现随机种子产生。流动性 `L` 的单位为股；两种冲击系数的单位是“每一个流动性尺度对应的基点”。中间价中的永久冲击只影响后续市场价格，即时冲击和半价差只进入当期成交价。

实施缺口按初始中间价 `m_0` 计算：`IS = Σ q_i,t * (fill_price_i,t - m_0)`，单位为货币。手续费为 `Σ q_i,t * fill_price_i,t * fee_bps / 10000`。终端未完成惩罚单列为 `remaining_shares * terminal_penalty_per_share`，单位为货币；默认值是可配置的教学假设，不是对真实机会成本的估计。总成本仅为 `IS + fee + terminal penalty`。奖励接口使用其负值；价格冲击已经通过成交价和后续中间价进入 IS，不会再作为独立惩罚重复相加。日志另列价差与即时冲击成本分解，它们是 IS 的解释项，不重复计入总成本。

本模型不模拟订单簿、限价单、部分撮合、卖单、市场微观结构或真实交易费用；默认主动买入全额成交，但受单笔剩余量和每步成交上限约束。结果用于比较这些假设下规则策略的相对表现，不能外推为真实市场收益或真实交易成本。

## 策略

- `twap`：将初始订单均匀分配至全部时间步，最后一步处理舍入余量。
- `front_loaded`：在前半段均匀完成目标订单。
- `back_loaded`：前半段等待，在后半段均匀完成。
- `spread_urgency`：按剩余时间提高执行紧迫度，并在价差变宽时降低当期计划量；最后一步尝试完成剩余订单。

策略返回连续股数计划；环境向下取整为整数股，再应用共同的剩余量和单步上限约束。TWAP 等规则以连续计划量表达执行节奏；未来 Q-learning 应另行定义有限动作集合（例如若干执行比例），不能把连续计划量误当成离散动作。本阶段不定义或使用该动作集合。`Strategy.learn(transition)` 仅保留接口，目前明确不执行学习。

## 运行

仅依赖 Python 3.10+ 标准库，无需安装第三方包。从本目录运行：

```powershell
python run_experiment.py --output results_rerun_01
python -m unittest discover -s tests -v
```

实验会在目标目录非空时停止，避免覆盖已有数据。默认 `results/` 已有第一轮结果；要重跑时请指定新的目录，例如 `python run_experiment.py --output results_rerun_01`。

默认实验对四种规则做全部有序策略配对，每个配对运行 20 个随机种子，另保存一个完整的 `twap` 对 `spread_urgency`、seed `20261103` 的 30 步案例。可调整订单量、步数、种子数和市场参数：

```powershell
python run_experiment.py --seeds 20 --steps 30 --initial-order 100000 --max-trade-per-step 10000 --spread-bps 6 --volatility-bps 2 --liquidity-shares 20000 --temp-impact-bps-per-liquidity-unit 2 --perm-impact-bps-per-liquidity-unit 0.6 --fee-bps 0.3 --terminal-penalty-per-share 0.25 --seed-start 20261103 --output results
```

成交成本、IS、手续费、终端未完成惩罚及未完成股数分别输出，不用少交易来隐藏订单未完成造成的代价。图表展示各策略对阵下每单位初始订单名义金额的平均总成本基点数；表格同时保留货币金额和未完成量。

## 产物与边界

- `results/step_log.csv`：每个策略配对、种子、参与方、时间步的观察、计划量、成交量、价格、成本分项和奖励。
- `results/scenario_metrics.csv`：每个种子、策略配对及参与方的最终指标。
- `results/strategy_pair_summary.csv`：以机构 A 为焦点、B 为对手的策略对阵跨种子平均值与标准差；每组 20 个随机种子，不把角色互换行计为新种子。包含 A 策略相对同一 B 对手下 A=TWAP 的差值区间。
- `results/paired_strategy_differences.csv`：保留每个种子相对 A=TWAP 的成本差，配对单位为种子。
- `results/cost_heatmap.svg`：策略对阵平均总成本图。
- `results/config.json`：本次实验配置、种子范围和策略列表。
- `results/representative_30_step.csv`：默认参数下 TWAP 对动态规则的单次完整 30 步案例；调整 `--steps` 后文件名同步变化。

未来可从 `Strategy.act` 接入离散动作策略，并用 `Transition` 和 `Strategy.learn(...)` 接入学习过程；本阶段没有实现状态编码、Q 表、经验回放、策略梯度或训练流程。

当前已覆盖成交约束与订单守恒、冲击关闭时机构间价格隔离、零成本可手算情形、固定种子扰动一致性、同一市场快照同步决策、未完成订单与终端惩罚记录。尚未实现订单簿、流动性供给方、部分成交、风险约束、真实市场校准和强化学习。

## 第三轮：最小表格型 Q-learning 接入

第三轮只接入一个可解释的表格型 Q-learning Agent，机构 B 固定为 TWAP；不引入 ABIDES、Gym 或其他大框架。运行：

```powershell
python run_qlearning.py --train-seeds 300 --validation-seeds 60 --test-seeds 100 --seed-start 20261103 --output results_round3_final_v2
python -m unittest discover -s tests -v
python audit_round3.py results_round3_final_v2
```

如果目标目录已有内容，入口会停止，不覆盖历史结果。训练、验证和测试分别使用不重叠的随机种子。候选参数只在训练种子上学习，在验证种子上选择最小平均成本；测试使用重新加载的 Q 表、`epsilon=0`、不再更新。默认 `gamma=1`，因为本问题是有限 30 步执行期限。

状态编码为 `(steps_remaining, own_remaining_fraction_bin, observable_spread_bin)`，不读取对手剩余订单、对手行动、下一期价格或 RNG 状态。动作是现有环境接受的剩余订单比例 `(0, .25, .5, .75, 1.0)`，乘以自己的剩余股数后仍受环境 `max_trade_per_step` 限制。TWAP 是连续股数计划，Q-learning 是离散比例动作，两者的比较以最终成本和订单完成率为准，不把原始动作数量当作同一空间。

Q 表更新为：`Q(s,a) <- Q(s,a) + alpha * [r + gamma * max_a' Q(s',a') - Q(s,a)]`；终止步的下一状态项为 0。`training_curve.csv` 保存每个候选在训练种子上的逐回合成本、未完成量、epsilon 和 Q 状态数；`q_update_example.json` 保存一条实际非零或终止步更新，`q_table_selected.json` 保存模型及状态编码配置，`model_reload_check.json` 验证选中模型保存后重新加载的测试动作序列一致，`validation_candidates.csv` 保存验证选择过程，`test_action_trace.csv` 保存测试期逐步状态、动作、奖励和 Q 更新字段，`test_action_distribution.csv` 保存冻结策略动作分布，`test_paired_comparison.csv` 对照 Q-learning、TWAP 和 `spread_urgency`。

ABIDES 的 `agent/examples/QLearningAgent.py` 仅作为算法思想参考：其状态和动作耦合 ABIDES 事件驱动交易框架，本项目未复制其类层次、未添加依赖。ABIDES 仓库声明 BSD 3-Clause；本项目不分发其代码。

## 第二轮验收与压力实验

第二轮结果单独写入 `results_round2/`，不会覆盖 `results/`。运行：

```powershell
python run_round2.py --seeds 100 --seed-start 20261103 --output results_round2_rerun_01
python -m unittest discover -s tests -v
```

压力对照固定 B 为 TWAP，每个场景使用相同的 100 个种子比较 A=TWAP 与 A=`spread_urgency`。配对统计单元是每个种子的 A 结果；每个均值的区间和“动态规则减 TWAP”的差值区间均按种子配对，使用 95% Student t 区间，临界值采用 Cornish-Fisher 近似。区间描述的是当前仿真分布，不代表真实市场不确定性。

压力场景分别改变价差（2/12 bp）、流动性（10,000/40,000 股）、冲击系数（半/双）、波动率（0/8 bp）以及仅手续费（0.3/1 bp）。流动性与冲击系数有各自独立场景；手续费场景只改费率，不改变价格路径或动作规则。

新增终端反例把每步成交上限设为 1,000 股，100,000 股母单在 30 步最多成交 30,000 股。剩余 70,000 股按每股 0.25 货币单位计终端惩罚；IS 仍只对已成交股数按执行价相对初始中间价计算，终端惩罚独立列示。

环境接口为：

- `reset(seed)`：重置 RNG、价格、订单和成本，返回第一步共享市场快照。
- `observe(agent_id)`：返回该机构自己的剩余订单量和共享只读市场快照，不暴露对手剩余量或当期行动。
- `step(actions)`：接收 A、B 已分别根据同一轮观察生成的完整行动映射，统一撮合并推进市场；也接受当前快照用于检查，但拒绝陈旧快照。
- `Strategy.act(observation)`：规则策略接口；`Strategy.learn(transition)` 仍抛出 `NotImplementedError`，本阶段没有学习代码。

供以后设计 Q-learning 的状态编码候选为 `(remaining_fraction_bin, steps_remaining_bin, spread_bin)`；动作可采用离散的剩余订单比例 `(0, .25, .5, .75, 1)`，再乘以剩余股数并受相同单步上限约束。该动作集合仅作为接口契约，尚未用于仿真策略比较；连续股数 TWAP 与离散动作学习者不能直接按原始动作数量视作相同策略。

第二轮主要输出：`pressure_summary_paired.csv`（配对成本、均值差及区间）、`pressure_paired_differences.csv`（逐场景、逐种子的差值）、`pressure_metrics.csv`（逐种子指标）、`pressure_focus_step_log.csv`（A 的逐步轨迹）、`baseline_cost_heatmap.svg`（明确 A/B 方向、单位和种子数）、`terminal_unfilled_counterexample.csv` 与 `terminal_unfilled_metrics.csv`（未完成订单反例）。原始第一轮 `results/` 保留为当时输出，不回写成第二轮口径。
